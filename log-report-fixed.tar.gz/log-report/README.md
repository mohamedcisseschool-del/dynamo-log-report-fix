# Dynamo log-report task

This repository contains the repaired Terminal-Bench 2 Harbor task for parsing
`/app/access.log` and producing `/app/report.json`.

Expected validation:

```bash
harbor run -p . -a oracle
harbor run -p . --agent nop
```

The oracle should receive reward 1. The no-op agent should receive reward 0.
